// reuse same transition component logic from web
export {
  transitionProps,
  extractTransitionData
} from 'web/runtime/components/transition'

import Transition from 'web/runtime/components/transition'

export default Transition
