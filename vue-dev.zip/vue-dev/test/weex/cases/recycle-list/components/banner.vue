<template recyclable="true">
  <div class="banner">
    <text class="title">BANNER</text>
  </div>
</template>

<style scoped>
  .banner {
    height: 120px;
    justify-content: center;
    align-items: center;
    background-color: rgb(162, 217, 192);
  }
  .title {
    font-weight: bold;
    color: #41B883;
    font-size: 60px;
  }
</style>
